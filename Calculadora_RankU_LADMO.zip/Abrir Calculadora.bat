@echo off
cd /d "%~dp0"
where mshta >nul 2>&1
if %errorlevel%==0 (
  start "" mshta "%~dp0calculadora_ranku.html"
  exit
)
echo Nao foi possivel iniciar a calculadora.
pause
